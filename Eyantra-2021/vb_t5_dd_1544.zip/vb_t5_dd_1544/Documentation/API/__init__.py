"""
This script is used to detect colour
It detect colour based on assumption that size of image will not change
and box position will also not change.
It assign colour to package name as package_name is fixed for fixed position.
9.19 pylint
"""
